#!/usr/local/bin/python3
"""
-------------------------------------------------------------------------------
SIMPLE VIDEO.PY

AUTHOR(S):     Peter Walker    pwalker@csumb.edu

PURPOSE-    .

CLASSES-    .
-------------------------------------------------------------------------------
"""
print("Not yet implemented...")
