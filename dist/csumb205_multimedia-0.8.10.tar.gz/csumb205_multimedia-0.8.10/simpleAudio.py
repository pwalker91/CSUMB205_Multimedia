#!/usr/local/bin/python3
"""
-------------------------------------------------------------------------------
SIMPLE AUDIO.PY

AUTHOR(S):     Peter Walker    pwalker@csumb.edu

PURPOSE-    .

CLASSES-    .
-------------------------------------------------------------------------------
"""
import wave
print("Not yet implemented...")
