CSUMB's CST205 - Simple Multimedia Manipulation
=======================

This project offers students acces to a simple RGBImage class, which
is built on the use of the Image module in the PIL package. As PIL is no
longer updated for Python 3, this package relies on Pillow.

More classes are in development for manipulation of audio and video.

This package will assume that the user is using at least Python 3.4

This project's Github IO page can be found here.
http://pwalker91.github.io/CSUMB205_Multimedia

The Python Package Index page can be found here.
https://pypi.python.org/pypi/csumb205-multimedia
