CSUMB's CST205 - Multimedia Manipulation
========================================

Simple Multimedia Classes
-------------------------

This project offers students access to simple Python classes that allow for the
manipulation of different multimedia types.

Currently, the only ones developed are:
    simpleImage
        rgbImage
        rgbPixel

The other modules installed are currently in developed. This includes:
  simpleAudio
  simpleVideo


Documentation
-----------------------------------------------------------
Documentation, and installation instructions, are available at
http://pwalker91.github.io/CSUMB205_Multimedia


-----------------------------------------------------------
Contributors
-----------------------------------------------------------
* Peter Walker https://github.com/pwalker91
